import pygame
import random

# Init
pygame.init()

# Screen
WIDTH, HEIGHT = 500, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Mini Shooter")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED   = (255, 0, 0)
GREEN = (0, 255, 0)

# Clock
clock = pygame.time.Clock()

# Player
player_size = 50
player = pygame.Rect(WIDTH//2 - player_size//2, HEIGHT-60, player_size, player_size)

# Bullets
bullets = []
bullet_speed = 7

# Enemies
enemies = []
enemy_size = 40
enemy_speed = 3

def spawn_enemy():
    x = random.randint(0, WIDTH-enemy_size)
    enemy = pygame.Rect(x, 0, enemy_size, enemy_size)
    enemies.append(enemy)

# Score
score = 0
font = pygame.font.SysFont("Arial", 24)

# Game loop
running = True
while running:
    clock.tick(30)
    screen.fill(BLACK)

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    # Keys
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player.left > 0:
        player.move_ip(-5, 0)
    if keys[pygame.K_RIGHT] and player.right < WIDTH:
        player.move_ip(5, 0)
    if keys[pygame.K_SPACE]:
        if len(bullets) < 5:  # limit shots
            bullets.append(pygame.Rect(player.centerx-5, player.top, 10, 20))

    # Update bullets
    for bullet in bullets[:]:
        bullet.move_ip(0, -bullet_speed)
        if bullet.bottom < 0:
            bullets.remove(bullet)

    # Spawn enemies randomly
    if random.randint(1, 25) == 1:  
        spawn_enemy()

    # Update enemies
    for enemy in enemies[:]:
        enemy.move_ip(0, enemy_speed)
        if enemy.top > HEIGHT:
            enemies.remove(enemy)  # enemy escaped

    # Check collisions
    for bullet in bullets[:]:
        for enemy in enemies[:]:
            if bullet.colliderect(enemy):
                bullets.remove(bullet)
                enemies.remove(enemy)
                score += 1
                break

    # Draw player
    pygame.draw.rect(screen, GREEN, player)

    # Draw bullets
    for bullet in bullets:
        pygame.draw.rect(screen, WHITE, bullet)

    # Draw enemies
    for enemy in enemies:
        pygame.draw.rect(screen, RED, enemy)

    # Draw score
    text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(text, (10, 10))

    # Update display
    pygame.display.flip()

pygame.quit()
